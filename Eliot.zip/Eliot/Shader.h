//./Eliot/Shader.h
#pragma once
#include <glad/glad.h>

GLuint LoadShaders(const char* vertex_path, const char* fragment_path);
